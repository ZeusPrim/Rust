

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const fetch = require('node-fetch');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('advice')
        .setDescription(`Get random advice`),
    async execute(interaction, client) {
        await interaction.deferReply()

        let infoWeb = await fetch('http://api.adviceslip.com/advice')
        let advice = await infoWeb.json();
        interaction.editReply({ content: advice.slip.advice })

    }

}