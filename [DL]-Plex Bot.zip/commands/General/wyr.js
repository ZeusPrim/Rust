

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const fetch = require('node-fetch');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('wyr')
        .setDescription(`Would you rather`),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false })

        let infoWeb = await fetch(`https://api.popcat.xyz/wyr`)
        let wyrQuestions = await infoWeb.json();
        interaction.editReply({ content: `**Would you rather?**\n1. ${wyrQuestions.ops1}\n**or**\n2. ${wyrQuestions.ops2}`, ephemeral: true })

    }

}