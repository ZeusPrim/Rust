

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const fetch = require('node-fetch');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('fact')
        .setDescription(`Get a random general fact`),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false })

        let infoWeb = await fetch(`https://api.popcat.xyz/fact`)
        let randomFact = await infoWeb.json();
        interaction.editReply({ content: `**🎲 RANDOM FACT**\n${randomFact.fact}` })

    }

}