

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const fetch = require('node-fetch');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dog')
        .setDescription(`Get a random picture of a dog`),
    async execute(interaction, client) {
        await interaction.deferReply()

        let infoWeb = await fetch('https://random.dog/woof.json')
        let dogimg = await infoWeb.json();
        let embed = new Discord.EmbedBuilder()
        .setImage(dogimg.url)
        .setColor(config.EmbedColors)
        interaction.editReply({ embeds: [embed] })

    }

}