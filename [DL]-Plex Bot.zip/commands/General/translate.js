

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const fetch = require('node-fetch');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('translate')
        .setDescription(`Translate a sentence from any language to english`)
        .addStringOption(option => option.setName('text').setDescription('The text to translate to english').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true })

        let text = interaction.options.getString("text");

        let infoWeb = await fetch(`https://api.popcat.xyz/translate?to=en&text=${text}`)
        let translatedText = await infoWeb.json();
        interaction.editReply({ content: `**Translated Text:**\n${translatedText.translated}`, ephemeral: true })

    }

}