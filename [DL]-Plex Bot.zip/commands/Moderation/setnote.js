

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const utils = require("../../utils.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setnote')
        .setDescription(`Set a note on a user`)
        .addUserOption(option => option.setName('user').setDescription('The user to set the note on').setRequired(true))
        .addStringOption(option => option.setName('note').setDescription('The note to set on the user').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        if(!interaction.member.permissions.has("ManageRoles")) return interaction.editReply({ content: lang.NoPermsMessage, ephemeral: true })

        let user = interaction.options.getUser("user");
        let noteText = interaction.options.getString("note");
        let member = interaction.guild.members.cache.get(user.id)

        const errorEmbed2 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.NoteLongerThan250)
        if(noteText.length > 250) return interaction.editReply({ embeds: [errorEmbed2], ephemeral: true })

        const errorEmbed3 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.NoteCantAddBot)
        if(member.bot) return interaction.editReply({ embeds: [errorEmbed3], ephemeral: true })

        await utils.ensureUserData(client, user.id, config.GuildID);

          let setNoteMsgVariable = lang.NoteSuccess.replace(/{user}/g, `<@!${user.id}>`)
          const successEmbed = new Discord.EmbedBuilder()
          .setAuthor({ name: `${lang.SuccessEmbedTitle}`, iconURL: `https://i.imgur.com/7SlmRRa.png` })
          .setColor(config.SuccessEmbedColor)
          .setDescription(setNoteMsgVariable)
          interaction.editReply({ embeds: [successEmbed], ephemeral: true });
          client.userData.set(user.id, noteText, "note");

    }

}