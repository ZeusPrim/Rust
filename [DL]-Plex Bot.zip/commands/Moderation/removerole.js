

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))

module.exports = {
    data: new SlashCommandBuilder()
        .setName('removerole')
        .setDescription(`Remove a role from a user`)
        .addUserOption(option => option.setName('user').setDescription('The user to remove the role from').setRequired(true))
        .addRoleOption(option => option.setName('role').setDescription('The role to remove from the user').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        if(!interaction.member.permissions.has("ManageRoles")) return interaction.editReply({ content: lang.NoPermsMessage, ephemeral: true })

        let user = interaction.options.getUser("user");
        let role = interaction.options.getRole("role");
        let user3 = interaction.guild.members.cache.get(user.id)

        const errorEmbed2 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.RemoveroleSelf)
        if(user.id === interaction.user.id) return interaction.editReply({ embeds: [errorEmbed2], ephemeral: true })

        let meHoist = interaction.guild.members.cache.find(m => m.user.id == client.user.id).roles.highest.rawPosition;
        let theHoist = role.rawPosition;
        if(theHoist > meHoist) {
            const errorEmbed = new Discord.EmbedBuilder()
            .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
            .setColor(config.ErrorEmbedColor)
            .setDescription(lang.AddroleHighestRole)
            return interaction.editReply({ embeds: [errorEmbed], ephemeral: true })
        }

        let meHoistt = interaction.guild.members.cache.get(interaction.user.id).roles.highest.rawPosition;
        let theHoistt = role.rawPosition;
        if(theHoistt > meHoistt) {
            const errorEmbed = new Discord.EmbedBuilder()
            .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
            .setColor(config.ErrorEmbedColor)
            .setDescription(lang.AddroleUserRoleNotAbove)
           return interaction.editReply({ embeds: [errorEmbed], ephemeral: true })
        }

        const errorEmbed4 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.RemoveroleNoRole)
        if(!user3.roles.cache.has(role.id)) return interaction.editReply({ embeds: [errorEmbed4], ephemeral: true })

        user3.roles.remove(role.id).catch(console.error);

        let roleremoved = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.RemoveroleEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .addFields([
            { name: `${lang.AddroleEmbedRole}`, value: `${role}` },
            { name: `${lang.RemoveroleEmbedRemovedBy}`, value: `${interaction.user}` },
            { name: `${lang.RemoveroleEmbedRemovedFrom}`, value: `${user}` },
            ])
        .setFooter({ text: `${interaction.guild.name}` })
        .setTimestamp()
        
                try{
                    let removeRoleeUserMsgVariable = lang.RemoveroleUserMsg.replace(/{guild-name}/g, `${interaction.guild.name}`).replace(/{role}/g, `${role.name}`)
                    user.send(removeRoleeUserMsgVariable);
                    interaction.editReply({ content: `You successfully removed a role from the user!` });
                }
                catch(e){
                    console.log(e);
                }


    }

}