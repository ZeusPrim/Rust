

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))

module.exports = {
    data: new SlashCommandBuilder()
        .setName('purge')
        .setDescription(`Purge a specific amount of messages in a channel`)
        .addNumberOption(option => option.setName('amount').setDescription('The amount of messages to purge').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        if(!interaction.member.permissions.has("ManageMessages")) return interaction.editReply({ content: lang.NoPermsMessage, ephemeral: true })

        let amount = interaction.options.getNumber("amount");
        if (amount > 100) amount = 100

        const logEmbed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ModerationEmbedTitle}`, iconURL: `https://i.imgur.com/FxQkyLb.png` })
        .setColor("Red")
        .addFields([
            { name: `${lang.ModerationEmbedAction}`, value: "``Purge``" },
            { name: `${lang.ModerationEmbedDetails}`, value: `\`\`${lang.ModerationEmbedStaff}\`\` <@!${interaction.user.id}>\n\`\`${lang.ModerationEmbedAmount}\`\` ${amount}\n\`\`${lang.ModerationEmbedChannel}\`\` ${interaction.channel}` },
            ])
        .setTimestamp()
    
        let logsChannel = interaction.guild.channels.cache.get(config.StaffLogsChannel);
                try {
                    let purgeAmountVariable = lang.PurgeCleared.replace(/{amount}/g, `${amount}`)
                    await interaction.channel.bulkDelete(amount)
                    interaction.editReply({ content: purgeAmountVariable, ephemeral: true })
                    if (logsChannel) logsChannel.send({ embeds: [logEmbed] })
                } catch(error) {
                    interaction.editReply({ content: lang.PurgeOld, ephemeral: true })
                }

    }

}