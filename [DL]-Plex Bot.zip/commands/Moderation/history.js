

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const moment = require('moment');
const utils = require("../../utils.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('history')
        .setDescription(`View a user's history`)
        .addUserOption(option => option.setName('user').setDescription('The user to view history').setRequired(true)),
    async execute(interaction, client) {
      await interaction.deferReply({ ephemeral: true });
        if(!interaction.member.permissions.has("ManageMessages")) return interaction.editReply({ content: lang.NoPermsMessage, ephemeral: true })

        let user = interaction.options.getUser("user");
        let member = interaction.guild.members.cache.get(user.id)

        await utils.ensureUserData(client, user.id, config.GuildID);

        let userData = client.userData.get(`${user.id}`);

          let historyEmbedTitleVariable = lang.HistoryEmbedTitle.replace(/{user-tag}/g, `${user.username}`)
          let avatarurl = user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 });
          let historyembed = new Discord.EmbedBuilder()
              .setColor("Orange")
              .setTitle(historyEmbedTitleVariable)
              .setThumbnail(avatarurl)
              .addFields([
                { name: `${lang.HistoryEmbedUserInfo}`, value: `\`\`${lang.HistoryEmbedName}\`\` <@!${user.id}>\n\`\`${lang.HistoryEmbedJoinedServer}\`\` ${moment(member.joinedAt).format('DD/MM/YY')}\n\`\`${lang.HistoryTotalMessages}\`\` ${userData.totalMessages.toLocaleString()}\n\`\`${lang.HistoryEmbedNote}\`\` ${userData.note}`, inline: true },
                { name: `${lang.HistoryEmbedWarnings}`, value: `${userData.warns}`, inline: true },
                { name: `${lang.HistoryEmbedTimeouts}`, value: `${userData.timeouts}`, inline: true },
                { name: `${lang.HistoryEmbedKicks}`, value: `${userData.kicks}`, inline: true },
                { name: `${lang.HistoryEmbedBans}`, value: `${userData.bans}`, inline: true },
                ])
              .setTimestamp()
              .setFooter({ text: `${interaction.guild.name}` })
              interaction.editReply({ embeds: [historyembed], ephemeral: true })

    }

}