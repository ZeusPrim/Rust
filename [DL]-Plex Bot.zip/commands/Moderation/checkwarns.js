

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const utils = require("../../utils.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('checkwarns')
        .setDescription(`View a user's warn history`)
        .addUserOption(option => option.setName('user').setDescription('The user to view warn history').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        if(!interaction.member.permissions.has("ManageMessages")) return interaction.editReply({ content: lang.NoPermsMessage, ephemeral: true })

        let user = interaction.options.getUser("user");

        await utils.ensureUserData(client, user.id, config.GuildID);

        const warnIDs = client.userData.get(user.id, 'warnings');
        warnIDs.reverse()

        const userWarnings = warnIDs.map((d) => {
        return d.map((w, i) => `\nStaff: \`${interaction.guild.members.cache.get(w.Moderator).user.username}\`\nReason: \`${w.Reason}\`\nDate: \`${w.Date}\``)
        })

        const errorEmbed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.CheckWarnsNotFound)

        if(!userWarnings.length) return interaction.editReply({ embeds: [errorEmbed], ephemeral: true })

        let Embed = new Discord.EmbedBuilder()
            .setAuthor({ name: `${user.username}'s Warnings`, iconURL: `${user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
            .setColor(config.EmbedColors)
            .setTimestamp()
            .setFooter({ text: `Total Warnings: ${warnIDs.length}`, iconURL: `${user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
            .setDescription(`${userWarnings.join('\n')}`)
            interaction.editReply({ embeds: [Embed], ephemeral: true })

    }

}