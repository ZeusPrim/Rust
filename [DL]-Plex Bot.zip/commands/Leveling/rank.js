

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const canvacord = require("canvacord");
const utils = require("../../utils.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rank')
        .setDescription(`Check your level and xp`),
    async execute(interaction, client) {
        if(config.LevelingSystem.Enabled  === false) return interaction.reply({ content: "This command has been disabled in the config!", ephemeral: true })
        await interaction.deferReply()

        await utils.ensureUserData(client, interaction.user.id, interaction.guild.id);

        let user = client.userData.get(`${interaction.user.id}`);
        let xpNeeded;
        if(user.level === 0) xpNeeded = 50
        if(user.level > 0) xpNeeded = user.level * config.LevelingSystem.XPNeeded;

        const card = new canvacord.Rank()
        .setUsername(interaction.user.username)
        .setRank(0)
        .setBackground("IMAGE", "./commands/Leveling/rankcard.png")
        .setLevel(user.level)
        .setCustomStatusColor(config.RankCard.StatusColor)
        .setLevelColor(config.RankCard.LevelColor)
        .setOverlay("#1c1c1c", "0.8", true)
        .setProgressBar(config.RankCard.ProgressBarColor, "COLOR")
        .setRank(0, "RANK", false)
        .setCurrentXP(user.xp)
        .setRequiredXP(xpNeeded)
        .setAvatar(interaction.user.displayAvatarURL({ format: "jpg" }));

    const img = await card.build();
    let attachment = new Discord.AttachmentBuilder(img, { name:"rank.png" });
    interaction.editReply({ files: [attachment] })

    }

}