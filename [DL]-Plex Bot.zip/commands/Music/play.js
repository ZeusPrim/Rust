

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const { QueryType } = require("discord-player")

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription(`Play a song`)
        .addStringOption(option => option.setName('query').setDescription('Song to play').setRequired(true)),
    async execute(interaction, client) {
        if(config.MusicSettings.Enabled === false) return interaction.reply({ content: "This command has been disabled in the config!", ephemeral: true })
        if(config.MusicSettings.EnableDJ && config.MusicSettings.DisabledCommands.includes('play')) return interaction.reply({ content: "This music command has been disabled!", ephemeral: true })
        if(config.MusicSettings.EnableDJ && !interaction.member.roles.cache.get(config.MusicSettings.DJRole) && !config.MusicSettings.AllowedUserCommands.includes('play')) return interaction.reply({ content: "This music command has been restricted to DJ\'s only!", ephemeral: true })
        if(!interaction.member.voice.channel) return interaction.reply({ content: `${client.emotes.error} | ${lang.NotInVoiceChannel}`, ephemeral: true })
        if(interaction.guild.members.me.voice.channel && interaction.member.voice.channel.id !== interaction.guild.members.me.voice.channel.id) return interaction.reply({ content: `${client.emotes.error} | You are not in the same voice channel as the bot!`, ephemeral: true })
        await interaction.deferReply()

        let embed = new Discord.EmbedBuilder()

        let url = interaction.options.getString("query")

        const result = await client.player.search(url, {
            requestedBy: interaction.member,
            searchEngine: QueryType.AUTO
        })
        .catch(error => console.log(error))
        if (!result || !result.tracks.length) return interaction.followUp({ content: `❌ | Track **${url}** not found!` });

        const queue = await client.player.nodes.create(interaction.guild, {
            skipOnNoStream: true,
            metadata: {
                channel: interaction.channel,
                client: interaction.guild.members.me,
                requestedBy: interaction.user,
            },
        });

        let justConnected;

        try {
            if (!queue.connection) {
                await queue.connect(interaction.member.voice.channel);
                justConnected = true;
            }
        } catch {
            client.player.deleteQueue(interaction.guildId);
            return await interaction.reply({ content: "Could not join your voice channel!", ephemeral: true });
        }


            if(result.playlist) {
                let AddedToQueuePlaylistVariable = lang.MusicPlaylistAddedToQueue.replace(/{playlist-name}/g, `${result.tracks[0].playlist.title}`).replace(/{playlist-link}/g, `${result.tracks[0].playlist.url}`)
                embed
                .setAuthor({ name: `${lang.MusicEmbedTitle}` })
                .setColor("Red")
                .setDescription(`${client.emotes.play} | ${AddedToQueuePlaylistVariable}`)
                .setFooter({ text: `${lang.MusicAddedBy} ${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
                .setTimestamp()
                queue.addTrack(result.playlist ? result.tracks : result.tracks[0])
            } else {
            let AddedToQueueVariable = lang.MusicAddedToQueue.replace(/{song-name}/g, `${result.tracks[0].title}`).replace(/{song-url}/g, `${result.tracks[0].url}`)
            embed
                .setAuthor({ name: `${lang.MusicEmbedTitle}` })
                .setColor("Red")
                .setDescription(`${client.emotes.play} | ${AddedToQueueVariable}`)
                .setFooter({ text: `${lang.MusicAddedBy} ${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
                .setTimestamp()
                queue.addTrack(result.playlist ? result.tracks : result.tracks[0])
            }

            if(justConnected) await queue.node.play()
            await interaction.editReply({embeds: [embed] })
        }

}