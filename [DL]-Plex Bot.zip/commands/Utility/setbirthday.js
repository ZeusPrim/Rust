

const { SlashCommandBuilder } = require('@discordjs/builders');
const Discord = require ("discord.js")
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('././config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('././lang.yml', 'utf8'))
const { parse } = require('date-and-time')
const utils = require("../../utils.js");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setbirthday')
        .setDescription(`Set your birthday`)
        .addStringOption(option => option.setName('date').setDescription('Your birthday, Example: May 4 2004').setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        if(config.BirthdaySystem.Enabled === false) return interaction.editReply({ content: "This command has been disabled in the config!", ephemeral: true })

        let dString = interaction.options.getString("date");

        const getAge = b => {
            let age = new Date().getFullYear() - new Date(b).getFullYear()
            const m = new Date().getMonth() - new Date(b).getMonth()
            if (m < 0 || (m === 0 && new Date().getDate() < new Date(b).getDate()))
                age--;
        
            return age
        }

        const capitalizeFirstLetter = string => {
            return string.charAt(0).toUpperCase() + string.slice(1);
          }

        const errorEmbed = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.BirthdayOnce)
        
        const errorEmbed2 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(lang.BirthdayDate)

        let bdayGreaterLocale = lang.BirthdayGreater.replace(/{year}/g, `${new Date().getFullYear() - 12}`)
        const errorEmbed3 = new Discord.EmbedBuilder()
        .setAuthor({ name: `${lang.ErrorEmbedTitle}`, iconURL: `https://i.imgur.com/MdiCK2c.png` })
        .setColor(config.ErrorEmbedColor)
        .setDescription(bdayGreaterLocale)

        await utils.ensureUserData(client, interaction.user.id, interaction.guild.id);

        if(client.userData.get(interaction.user.id, `birthday`) !== null) return interaction.editReply({ embeds: [errorEmbed], ephemeral: true })

        const birthd = capitalizeFirstLetter(dString)
        const date = parse(birthd, 'MMMM D YYYY')
        if(!date || isNaN(date)) return interaction.editReply({ embeds: [errorEmbed2], ephemeral: true })

        const age = getAge(dString)
        if (age <= 12) return interaction.editReply({ embeds: [errorEmbed3], ephemeral: true })

        let bdayDescLocale = lang.BirthdayEmbedDescription.replace(/{date}/g, `${birthd}`)
        let embed = new Discord.EmbedBuilder()
        .setColor(config.EmbedColors)
        .setTitle(lang.BirthdayEmbedTitle)
        .setDescription(bdayDescLocale)
        .setFooter({ text: `${interaction.user.username}`, iconURL: `${interaction.user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
        .setTimestamp()

        client.userData.set(interaction.user.id, birthd, `birthday`)

        interaction.editReply({ embeds: [embed], ephemeral: true })
    }
}