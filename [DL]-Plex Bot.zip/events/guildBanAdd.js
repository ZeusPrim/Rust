const Discord = require("discord.js");
const fs = require('fs');
const yaml = require("js-yaml")
const config = yaml.load(fs.readFileSync('./config.yml', 'utf8'))
const lang = yaml.load(fs.readFileSync('./lang.yml', 'utf8'))
const utils = require("../utils.js");

module.exports = async (client, ban) => {

	const fetchedLogs = await ban.guild.fetchAuditLogs({
		limit: 1,
		type: Discord.AuditLogEvent.MemberBanAdd,
	});

	const banLog = fetchedLogs.entries.first();
  if (!banLog) return;
  const { executor, target } = banLog;
  if (executor.id == client.user.id) return;

  if (target.id === ban.user.id) {

    await utils.ensureUserData(client, ban.user.id, ban.guild.id);

      let reason;
      if(!fetchedLogs.entries.first().reason) reason = "No reason specified"
      if(fetchedLogs.entries.first().reason) reason = fetchedLogs.entries.first().reason

      const logEmbed = new Discord.EmbedBuilder()
      .setAuthor({ name: `${lang.ModerationEmbedTitle}`, iconURL: `https://i.imgur.com/FxQkyLb.png` })
      .setColor("Red")
      .addFields([
        { name: `${lang.ModerationEmbedAction}`, value: "``Ban (Discord)``" },
        { name: `${lang.ModerationEmbedDetails}`, value: `\`\`${lang.ModerationEmbedUser}\`\` <@!${ban.user.id}>\n\`\`${lang.ModerationEmbedStaff}\`\` <@!${executor.id}>\n\`\`${lang.ModerationEmbedReason}\`\` ${reason}` },
        ])
      .setTimestamp()
      .setFooter({ text: `#${client.guildData.get(`${ban.guild.id}`, `cases`)}`, iconURL: `${ban.user.displayAvatarURL({ format: 'png', dynamic: true, size: 1024 })}` })
      let logsChannel = ban.guild.channels.cache.get(config.StaffLogsChannel);

      client.guildData.inc(ban.guild.id, "cases");
      client.userData.inc(`${ban.user.id}`, "bans");
      if (logsChannel) logsChannel.send({ embeds: [logEmbed] })
      }

};